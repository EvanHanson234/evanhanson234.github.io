$(".animated-line").one("animationend", function() {
    $(this).removeClass("animated-line");
  });
  